import Table from '@/app/ui/customers/table';
export default function Page() {
    return <p>Customers Page</p>;
  }